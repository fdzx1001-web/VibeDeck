/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ImagePin, Board, PinComment, AppNotification } from './types';
import { INITIAL_PINS, INITIAL_BOARDS, INITIAL_COMMENTS } from './data';
import { downloadImageWithRetries } from './utils/downloader';
import { prefetchImages, clearImageCache } from './utils/imageCache';

// Import Icons
import {
  Home,
  PlusCircle,
  FolderHeart,
  Image as ImageIcon,
  Search,
  Sparkles,
  Bookmark,
  Heart,
  Download,
  Trash2,
  RefreshCw,
  FolderMinus,
  Check,
  User
} from 'lucide-react';

// Import Components
import { PinCard } from './components/PinCard';
import { BoardSelectorModal } from './components/BoardSelectorModal';
import { NotificationsPanel } from './components/NotificationsPanel';
import { UploadScreen } from './components/UploadScreen';
import { DetailScreen } from './components/DetailScreen';
import { CachedImage } from './components/CachedImage';

export default function App() {
  // ---- Core States (Initialized with localStorage support for client persistence) ----
  const [pins, setPins] = useState<ImagePin[]>(() => {
    const saved = localStorage.getItem('pinterest_pins');
    return saved ? JSON.parse(saved) : INITIAL_PINS;
  });

  const [boards, setBoards] = useState<Board[]>(() => {
    const saved = localStorage.getItem('pinterest_boards');
    return saved ? JSON.parse(saved) : INITIAL_BOARDS;
  });

  const [comments, setComments] = useState<PinComment[]>(() => {
    const saved = localStorage.getItem('pinterest_comments');
    return saved ? JSON.parse(saved) : INITIAL_COMMENTS;
  });

  const [downloadedIds, setDownloadedIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('pinterest_downloaded_ids');
    return saved ? JSON.parse(saved) : [];
  });

  // ---- Persistent Profile Details state ----
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('vibe_deck_profile');
    return saved ? JSON.parse(saved) : {
      fullName: 'Local Creator',
      username: 'localcreator',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
    };
  });

  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const profileFileRef = useRef<HTMLInputElement>(null);

  // Handle profile avatar selection & compression (Web SDK BitmapFactory-like canvas compression pipeline)
  const handleProfileAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      triggerNotification('Please select a valid image file for your profile.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Compress avatar to a lightweight, high density 150x150 square format
        canvas.width = 150;
        canvas.height = 150;
        
        const size = Math.min(img.width, img.height);
        const sx = (img.width - size) / 2;
        const sy = (img.height - size) / 2;

        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, sx, sy, size, size, 0, 0, 150, 150);

        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.82);
        
        // Update both in-progress form values or state
        setProfile((prev: any) => ({ ...prev, avatar: compressedBase64 }));
        triggerNotification('Profile avatar updated and optimized successfully!', 'success');
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // ---- Navigation & UI States ----
  const [activeTab, setActiveTab] = useState<'home' | 'upload' | 'boards' | 'gallery'>('home');
  const [selectedPin, setSelectedPin] = useState<ImagePin | null>(null);
  const [selectedBoardId, setSelectedBoardId] = useState<string>('all'); // Filter feed by board
  const [searchQuery, setSearchQuery] = useState('');
  const [savingPinForBoard, setSavingPinForBoard] = useState<ImagePin | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // ---- Pull-To-Refresh Gesture System ----
  const [pullY, setPullY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const pullStartYRef = useRef(0);
  const isDraggingRef = useRef(false);

  const handlePullStart = (clientY: number) => {
    if (window.scrollY > 0 || isRefreshing) return;
    pullStartYRef.current = clientY;
    isDraggingRef.current = true;
  };

  const handlePullMove = (clientY: number, preventDefault: () => void = () => {}) => {
    if (!isDraggingRef.current || isRefreshing) return;
    const deltaY = clientY - pullStartYRef.current;
    
    if (deltaY > 0) {
      if (window.scrollY === 0) {
        preventDefault();
        const pull = Math.min(100, deltaY * 0.45);
        setPullY(pull);
      }
    } else {
      setPullY(0);
    }
  };

  const handlePullEnd = async () => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;

    if (pullY > 55) {
      setIsRefreshing(true);
      setPullY(65); // Lock spinner location during refresh task
      
      try {
        await clearImageCache();
        triggerNotification('Feed cache updated and re-indexed!', 'success');
        
        // Simulating standard mobile network speed/latency
        await new Promise((resolve) => setTimeout(resolve, 1200));
      } catch (err) {
        console.error('Refresh task error:', err);
      } finally {
        setIsRefreshing(false);
        setPullY(0);
      }
    } else {
      setPullY(0);
    }
  };

  // ---- Temp states for profile updating ----
  const [editFullName, setEditFullName] = useState('');
  const [editUsername, setEditUsername] = useState('');

  // ---- Sync updates to localStorage ----
  useEffect(() => {
    localStorage.setItem('pinterest_pins', JSON.stringify(pins));
  }, [pins]);

  useEffect(() => {
    localStorage.setItem('pinterest_boards', JSON.stringify(boards));
  }, [boards]);

  useEffect(() => {
    localStorage.setItem('pinterest_comments', JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem('pinterest_downloaded_ids', JSON.stringify(downloadedIds));
  }, [downloadedIds]);

  useEffect(() => {
    localStorage.setItem('vibe_deck_profile', JSON.stringify(profile));
  }, [profile]);

  // ---- Background Prefetching (Replicates Android image caching for absolute zero lag) ----
  useEffect(() => {
    const urlsToPrefetch = pins.slice(0, 8).map((p) => p.url);
    prefetchImages(urlsToPrefetch);
  }, [pins]);

  // ---- Notifications management helpers ----
  const triggerNotification = (
    message: string,
    type: AppNotification['type'],
    duration = 4500
  ) => {
    const id = `notif_${Date.now()}`;
    const newNotif: AppNotification = { id, message, type };
    setNotifications((prev) => [...prev, newNotif]);

    if (duration > 0) {
      setTimeout(() => {
        dismissNotification(id);
      }, duration);
    }
    return id;
  };

  const updateNotificationProgress = (id: string, progress: number, retryCount?: number) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, progress, retryCount } : n))
    );
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  // ---- Performance Centric Action Controllers ----

  // 1. Image Download Action Handler containing retry backoff notifications
  const handleDownloadTask = async (pin: ImagePin) => {
    const notifId = triggerNotification(
      `Initializing secure download task for "${pin.title}"...`,
      'downloading',
      0 // Maintain notify block open during download
    );

    try {
      await downloadImageWithRetries(
        pin.url,
        `${pin.title.toLowerCase().replace(/\s+/g, '_')}.jpg`,
        {
          onProgress: (progress) => {
            updateNotificationProgress(notifId, progress);
          },
          onRetry: (retryCount) => {
            updateNotificationProgress(notifId, 50, retryCount);
            // Quick status update text inside the active task
            setNotifications((prev) =>
              prev.map((n) =>
                n.id === notifId
                  ? { ...n, message: `Intermittent connection drop. Retrying download... (${retryCount}/3)` }
                  : n
              )
            );
          },
          onSuccess: () => {
            dismissNotification(notifId);
            triggerNotification(`Saved successfully to media directory /DCIM/Camera!`, 'success');

            // Record as downloaded for the local Mock Gallery viewing
            if (!downloadedIds.includes(pin.id)) {
              setDownloadedIds((prev) => [...prev, pin.id]);
            }

            // Increment local download counts
            setPins((prevPins) =>
              prevPins.map((p) => (p.id === pin.id ? { ...p, downloadCount: p.downloadCount + 1 } : p))
            );
          },
          onFailure: (err) => {
            dismissNotification(notifId);
            triggerNotification(`Failed to save image asset: ${err.message}`, 'error', 6000);
          },
        }
      );
    } catch {
      // Handled in callback
    }
  };

  // 2. Add to board actions
  const handleSaveToBoard = (boardId: string) => {
    if (!savingPinForBoard) return;

    const pinId = savingPinForBoard.id;
    const targetBoard = boards.find((b) => b.id === boardId);

    setPins((prevPins) =>
      prevPins.map((p) => {
        if (p.id === pinId) {
          const alreadySaved = p.boardIds.includes(boardId);
          const updatedBoardIds = alreadySaved
            ? p.boardIds.filter((bId) => bId !== boardId)
            : [...p.boardIds, boardId];

          triggerNotification(
            alreadySaved
              ? `Removed from Board: "${targetBoard?.name}"`
              : `Successfully saved to Board: "${targetBoard?.name}"`,
            alreadySaved ? 'info' : 'success'
          );

          // If current pin is selected in detail screen, sync and update active display status
          if (selectedPin && selectedPin.id === pinId) {
            setSelectedPin({ ...selectedPin, boardIds: updatedBoardIds });
          }

          return { ...p, boardIds: updatedBoardIds };
        }
        return p;
      })
    );

    setSavingPinForBoard(null);
  };

  const handleCreateNewBoard = (name: string) => {
    const id = `board_${Date.now()}`;
    const newBoard: Board = {
      id,
      name,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setBoards((prev) => [...prev, newBoard]);
    triggerNotification(`Created Board: "${name}"`, 'success');

    // Automatically assign the active saving pin to this brand-new board
    if (savingPinForBoard) {
      const pinId = savingPinForBoard.id;
      setPins((prevPins) =>
        prevPins.map((p) => {
          if (p.id === pinId) {
            const updatedBoardIds = [...p.boardIds, id];

            triggerNotification(`Saved to newly created Board: "${name}"`, 'success');

            if (selectedPin && selectedPin.id === pinId) {
              setSelectedPin({ ...selectedPin, boardIds: updatedBoardIds });
            }

            return { ...p, boardIds: updatedBoardIds };
          }
          return p;
        })
      );
      setSavingPinForBoard(null);
    }
  };

  // 3. User Upload submission callback
  const handlePublishPin = (newPin: ImagePin) => {
    const pinWithProfile = {
      ...newPin,
      author: profile.fullName,
      authorAvatar: profile.avatar
    };
    setPins((prev) => [pinWithProfile, ...prev]);
  };

  // 4. Like / Unlike actions
  const handleLikeToggle = (pinId: string) => {
    setPins((prevPins) =>
      prevPins.map((p) => {
        if (p.id === pinId) {
          const willLike = !p.isLikedByUser;
          const updatedPin = {
            ...p,
            isLikedByUser: willLike,
            likes: p.likes + (willLike ? 1 : -1),
          };

          // Sync active full-screen selected details pin
          if (selectedPin && selectedPin.id === pinId) {
            setSelectedPin(updatedPin);
          }

          return updatedPin;
        }
        return p;
      })
    );
  };

  // 5. Publish local comment
  const handleAddComment = (pinId: string, text: string) => {
    const newComment: PinComment = {
      id: `comment_${Date.now()}`,
      pinId,
      author: profile.fullName,
      authorAvatar: profile.avatar,
      text,
      timestamp: 'Just now',
    };

    setComments((prev) => [newComment, ...prev]);

    // Force update comments counter
    setPins((prevPins) =>
      prevPins.map((p) => {
        if (p.id === pinId) {
          const updatedPin = { ...p, commentsCount: p.commentsCount + 1 };
          if (selectedPin && selectedPin.id === pinId) {
            setSelectedPin(updatedPin);
          }
          return updatedPin;
        }
        return p;
      })
    );
  };

  // 6. Delete Pin (for uploaded ones)
  const handleDeletePin = (pinId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPins((prev) => prev.filter((p) => p.id !== pinId));
    setDownloadedIds((prev) => prev.filter((id) => id !== pinId));
    if (selectedPin?.id === pinId) {
      setSelectedPin(null);
    }
    triggerNotification('Pin removed from local storage feed.', 'info');
  };

  // ---- Masonry Balancing Logic (Dynamic 2-Column Stagger Height balance) ----
  const filteredPins = useMemo(() => {
    return pins.filter((pin) => {
      // 1. Filter by search query
      const matchSearch =
        pin.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pin.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pin.author.toLowerCase().includes(searchQuery.toLowerCase());

      // 2. Filter by board
      const matchBoard = selectedBoardId === 'all' || pin.boardIds.includes(selectedBoardId);

      return matchSearch && matchBoard;
    });
  }, [pins, selectedBoardId, searchQuery]);

  const [col1, col2] = useMemo(() => {
    const column1: ImagePin[] = [];
    const column2: ImagePin[] = [];
    let col1Height = 0;
    let col2Height = 0;

    filteredPins.forEach((item) => {
      const aspect = item.width / item.height;
      // height multiplier relative to standard pixel columns segment width
      const approxHeight = 1 / aspect;

      if (col1Height <= col2Height) {
        column1.push(item);
        col1Height += approxHeight + 0.12; // 0.12 account for vertical padding compensation
      } else {
        column2.push(item);
        col2Height += approxHeight + 0.12;
      }
    });

    return [column1, column2];
  }, [filteredPins]);

  // Downloaded photos matching gallery
  const galleryPins = useMemo(() => {
    return pins.filter((p) => downloadedIds.includes(p.id));
  }, [pins, downloadedIds]);

  return (
    <div 
      className="min-h-screen bg-black text-neutral-100 font-sans pb-28 select-none"
      onTouchStart={(e) => handlePullStart(e.touches[0].clientY)}
      onTouchMove={(e) => handlePullMove(e.touches[0].clientY, () => {
        if (e.cancelable) e.preventDefault();
      })}
      onTouchEnd={handlePullEnd}
      onMouseDown={(e) => handlePullStart(e.clientY)}
      onMouseMove={(e) => handlePullMove(e.clientY)}
      onMouseUp={handlePullEnd}
      onMouseLeave={handlePullEnd}
    >
      {/* Top Header: Android Top Navigation */}
      <header className="sticky top-0 z-40 bg-black/85 backdrop-blur-md border-b border-neutral-900 px-4 py-3.5 flex items-center justify-between select-none">
        
        {/* VibeDeck. Minimalist lowercase looping 'v' Logo element */}
        <div
          onClick={() => {
            setSelectedPin(null);
            setSelectedBoardId('all');
            setActiveTab('home');
          }}
          className="flex items-center gap-2.5 cursor-pointer flex-shrink-0 select-none"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-velvet shadow-[0_4px_12px_rgba(139,0,0,0.4)] hover:scale-105 active:scale-95 transition-all">
            {/* Minimalist looping 'v' svg or styling */}
            <svg
              className="h-5 w-5 text-brand-cream animate-pulse"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="3.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 7l7 10 9-14" />
            </svg>
          </div>
          <span className="font-display text-xl font-bold tracking-tight text-brand-cream">
            VibeDeck<span className="text-brand-velvet">.</span>
          </span>
        </div>

        {/* Dynamic Context Header elements (Search field active inside Home Flow) */}
        {activeTab === 'home' && !selectedPin ? (
          <div className="mx-4 flex-grow max-w-lg relative">
            <div className="absolute inset-y-0 left-3 flex items-center text-neutral-500">
              <Search className="h-4 w-4" />
            </div>
            <input
              type="text"
              placeholder="Search visual layouts, designers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full bg-neutral-900 border border-neutral-850 py-2 pl-9 pr-4 font-sans text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-neutral-700 transition-colors"
            />
          </div>
        ) : (
          <div className="flex-grow mx-4 max-w-lg hidden sm:block">
            <p className="font-sans text-xs text-neutral-500 text-right capitalize italic">
              Viewing Screen Context: {selectedPin ? `Pin Detail "${selectedPin.title}"` : activeTab}
            </p>
          </div>
        )}
      </header>

      {/* Jetpack Compose PullRefreshIndicator equivalent spinning wheel */}
      <div 
        className="fixed left-1/2 -translate-x-1/2 z-50 pointer-events-none transition-all duration-75"
        style={{ 
          top: `${48 + pullY}px`, // drops down beautifully below the sticky header
          opacity: pullY > 15 ? 1 : 0,
          transform: `translate(-50%, -50%) scale(${pullY > 15 ? 1 : 0.8})`
        }}
      >
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#121212] border border-neutral-850 shadow-[0_6px_20px_rgba(0,0,0,0.8)] text-brand-velvet">
          <svg
            className={`h-5.5 w-5.5 text-brand-velvet ${isRefreshing ? 'animate-spin' : ''}`}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3.2"
            style={{
              transform: isRefreshing ? undefined : `rotate(${pullY * 4.5}deg)`
            }}
          >
            <path strokeLinecap="round" d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67" />
          </svg>
        </div>
      </div>

      {/* Main Viewport Routing Canvas */}
      <main className="relative">
        
        {/* Global Floating Toast Alert Node */}
        <NotificationsPanel notifications={notifications} onDismiss={dismissNotification} />

        <AnimatePresence mode="wait" initial={false}>
          {selectedPin ? (
            <motion.div
              key="detail_view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: "easeInOut" }}
            >
              <DetailScreen
                pin={selectedPin}
                pins={pins}
                comments={comments}
                relatedPins={pins.filter((p) => p.id !== selectedPin.id).slice(0, 10)}
                onBack={() => setSelectedPin(null)}
                onLikeToggle={handleLikeToggle}
                onSaveBoardClick={(p) => setSavingPinForBoard(p)}
                onDownloadClick={handleDownloadTask}
                onAddComment={handleAddComment}
                onSelectPin={(p) => setSelectedPin(p)}
              />
            </motion.div>
          ) : (
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
            >
              <>
                {activeTab === 'home' && (
              <div className="mx-auto max-w-7xl px-4 py-6">
                
                {/* Board filtration horizontal slider block */}
                <div className="mb-6 overflow-x-auto scrollbar-none py-1.5 whitespace-nowrap">
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedBoardId('all')}
                      className={`rounded-full px-5 py-2 font-sans text-xs font-bold transition-all select-none cursor-pointer border ${
                        selectedBoardId === 'all'
                          ? 'bg-brand-velvet text-brand-cream border-brand-velvet font-extrabold scale-102 shadow-lg'
                          : 'bg-neutral-900 text-neutral-400 border-neutral-850 hover:text-white hover:bg-neutral-850'
                      }`}
                    >
                      All Feed
                    </button>
                    {boards.map((b) => (
                      <button
                        key={b.id}
                        onClick={() => setSelectedBoardId(b.id)}
                        className={`rounded-full px-5 py-2 font-sans text-xs font-bold transition-all select-none cursor-pointer border ${
                          selectedBoardId === b.id
                            ? 'bg-brand-velvet text-brand-cream border-brand-velvet font-extrabold scale-102 shadow-lg'
                            : 'bg-neutral-900 text-neutral-400 border-neutral-850 hover:text-white hover:bg-neutral-850'
                        }`}
                      >
                        {b.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* VibeDeck Atmospheric Splash Banner */}
                {selectedBoardId === 'all' && searchQuery === '' && (
                  <div className="mb-8 rounded-[24px] bg-gradient-to-br from-brand-surface to-black border border-neutral-850 p-6 md:p-8 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6 animate-fade-in select-none">
                    <div className="space-y-2.5 max-w-lg z-10 font-sans">
                      <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-neutral-900/60 border border-neutral-800">
                        <span className="h-1.5 w-1.5 rounded-full bg-brand-velvet animate-pulse" />
                        <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-brand-cream/90">
                          Designed by Zotx Studios
                        </span>
                      </div>
                      <h2 className="font-display text-2xl md:text-3xl font-black text-brand-cream leading-tight">
                        Collect what inspires you. <span className="text-red-500 underline decoration-brand-velvet/40">Instantly.</span>
                      </h2>
                    </div>
                    <div className="flex gap-4.5 z-10 shrink-0">
                      <div className="flex flex-col items-center bg-brand-surface/80 rounded-2xl px-5 py-4 border border-neutral-800 text-center min-w-[100px]">
                        <span className="font-mono text-lg font-black text-white">{pins.length}</span>
                        <span className="font-sans text-[10px] text-neutral-500 uppercase font-semibold">Pins</span>
                      </div>
                      <div className="flex flex-col items-center bg-brand-surface/80 rounded-2xl px-5 py-4 border border-neutral-800 text-center min-w-[100px]">
                        <span className="font-mono text-lg font-black text-white">{boards.length}</span>
                        <span className="font-sans text-[10px] text-neutral-500 uppercase font-semibold">Boards</span>
                      </div>
                    </div>
                    
                    {/* Atmospheric Glow Vector */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-brand-velvet/5 rounded-full filter blur-3xl -z-10" />
                  </div>
                )}

                {/* Staggered double-column masonry container */}
                {pins.length === 0 ? (
                  <div className="py-32 text-center animate-fade-in flex flex-col items-center justify-center">
                    <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-neutral-900 border border-neutral-800 text-brand-cream shadow-[0_4px_12px_rgba(0,0,0,0.5)]">
                      <PlusCircle className="h-6 w-6" />
                    </div>
                    <p className="font-display text-base font-medium text-brand-cream tracking-tight max-w-sm px-6">
                      Your deck is empty. Tap '+' to upload your first inspiration.
                    </p>
                  </div>
                ) : filteredPins.length > 0 ? (
                  <div className="grid grid-cols-2 gap-3 md:gap-4.5 max-w-full">
                    
                    {/* Column 1 */}
                    <div className="flex flex-col">
                      <AnimatePresence mode="popLayout">
                        {col1.map((pin) => (
                          <motion.div
                            key={pin.id}
                            layout
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            transition={{ type: "spring", stiffness: 350, damping: 30 }}
                            className="relative group"
                          >
                            <PinCard
                              pin={pin}
                              onClick={() => setSelectedPin(pin)}
                              onSaveBoardClick={() => setSavingPinForBoard(pin)}
                              onDownloadClick={() => handleDownloadTask(pin)}
                            />
                            {pin.id.startsWith('local_pin_') && (
                              <button
                                onClick={(e) => handleDeletePin(pin.id, e)}
                                className="absolute top-4 left-4 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-red-950/90 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-900 hover:text-white"
                                title="Delete Uploaded Pin"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    </div>

                    {/* Column 2 */}
                    <div className="flex flex-col">
                      <AnimatePresence mode="popLayout">
                        {col2.map((pin) => (
                          <motion.div
                            key={pin.id}
                            layout
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            transition={{ type: "spring", stiffness: 350, damping: 30 }}
                            className="relative group"
                          >
                            <PinCard
                              pin={pin}
                              onClick={() => setSelectedPin(pin)}
                              onSaveBoardClick={() => setSavingPinForBoard(pin)}
                              onDownloadClick={() => handleDownloadTask(pin)}
                            />
                            {pin.id.startsWith('local_pin_') && (
                              <button
                                onClick={(e) => handleDeletePin(pin.id, e)}
                                className="absolute top-4 left-4 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-red-950/90 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-900 hover:text-white"
                                title="Delete Uploaded Pin"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            )}
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    </div>

                  </div>
                ) : (
                  <div className="py-24 text-center">
                    <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-neutral-900 text-neutral-550">
                      <FolderMinus className="h-6 w-6" />
                    </div>
                    <p className="font-sans text-sm font-semibold text-neutral-300">No layout elements found</p>
                    <p className="font-sans text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
                      Try resetting your board filters or upload an aesthetic snapshot using the Create tab!
                    </p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'upload' && (
              <UploadScreen
                onAddPin={handlePublishPin}
                showSuccessToast={(msg) => triggerNotification(msg, 'success')}
                showErrorToast={(msg) => triggerNotification(msg, 'error')}
                onNavigateHome={() => {
                  setActiveTab('home');
                  setSelectedBoardId('all');
                }}
              />
            )}

            {activeTab === 'boards' && (
              <div className="mx-auto max-w-4xl px-4 py-8">
                <div className="mb-8 flex items-center justify-between">
                  <div>
                    <h2 className="font-sans text-2xl font-black text-white">Your Collections</h2>
                    <p className="font-sans text-xs text-neutral-450 mt-1">
                      Boards organized locally under client-side memory spaces.
                    </p>
                  </div>

                  {/* Manual Creation block helper */}
                  <button
                    onClick={() => {
                      const name = prompt('Enter name of your new board:');
                      if (name && name.trim()) {
                        handleCreateNewBoard(name.trim());
                      }
                    }}
                    className="flex h-9 items-center justify-center gap-1.5 rounded-full bg-brand-velvet px-4 text-xs font-bold text-brand-cream hover:bg-brand-velvet-hover active:scale-95 transition-all cursor-pointer shadow-md"
                  >
                    <span>New Board</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  {boards.map((b) => {
                    const boardPins = pins.filter((p) => p.boardIds.includes(b.id));
                    return (
                      <div
                        key={b.id}
                        onClick={() => {
                          setSelectedBoardId(b.id);
                          setActiveTab('home');
                          setSelectedPin(null);
                        }}
                        className="group relative overflow-hidden rounded-2xl border border-neutral-850 bg-neutral-950 p-5 cursor-pointer hover:border-neutral-700 transition-all shadow-md select-none"
                      >
                        <div className="mb-4 flex gap-2">
                          {/* Mini Grid Cover indicators */}
                          <div className="grid grid-cols-3 gap-1.5 w-full h-24 overflow-hidden rounded-xl bg-neutral-900">
                            {boardPins.slice(0, 3).map((bp, idx) => (
                              <img
                                key={idx}
                                src={bp.url}
                                alt="preview"
                                referrerPolicy="no-referrer"
                                className="h-full w-full object-cover"
                              />
                            ))}
                            {boardPins.length === 0 && (
                              <div className="col-span-3 flex items-center justify-center text-neutral-600 font-mono text-[10px] uppercase">
                                Empty Portfolio
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-sans text-base font-bold text-white group-hover:text-red-500 transition-colors">
                              {b.name}
                            </h3>
                            <p className="font-sans text-xs text-neutral-500 mt-1">
                              {b.description || 'Virtual portfolio container'}
                            </p>
                          </div>

                          <span className="rounded-full bg-neutral-900 px-3 py-1 font-sans text-[10px] font-bold text-neutral-400">
                            {boardPins.length} pins
                          </span>
                        </div>

                        {/* Direct board deletion */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Delete board "${b.name}"? Pins will remain in feed.`)) {
                              setBoards((prev) => prev.filter((board) => board.id !== b.id));
                              // Unassign pins from this board
                              setPins((prevPins) =>
                                prevPins.map((p) => ({
                                  ...p,
                                  boardIds: p.boardIds.filter((bId) => bId !== b.id),
                                }))
                              );
                              triggerNotification('Board deleted successfully.', 'info');
                            }
                          }}
                          className="absolute top-5 right-5 h-8 w-8 items-center justify-center rounded-full bg-neutral-900 text-neutral-500 hover:text-red-500 hidden group-hover:flex transition-all active:scale-90"
                          title="Delete Board"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === 'gallery' && (
              <div className="mx-auto max-w-7xl px-4 py-8">
                {/* Unified Android Profile Header layout */}
                <div className="flex flex-col items-center text-center mt-6 mb-12">
                  <div className="relative group cursor-pointer mb-4">
                    <div className="relative h-24 w-24 rounded-full overflow-hidden border-2 border-brand-velvet/55 shadow-[0_8px_24px_rgba(139,0,0,0.3)] bg-neutral-900">
                      <img
                        src={profile.avatar}
                        alt={profile.fullName}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
                      />
                      <div 
                        onClick={() => profileFileRef.current?.click()}
                        className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                        title="Tapping launches image picker"
                      >
                        <PlusCircle className="h-5 w-5 text-brand-cream animate-bounce" />
                        <span className="text-[9px] font-sans font-bold text-brand-cream uppercase tracking-wide mt-1">Upload</span>
                      </div>
                    </div>
                  </div>

                  <h1 className="font-display text-2xl font-black text-white tracking-tight">
                    {profile.fullName}
                  </h1>
                  <p className="font-sans text-[13px] text-neutral-400 font-medium mt-1">
                    @{profile.username}
                  </p>

                  <button
                    onClick={() => {
                      setEditFullName(profile.fullName);
                      setEditUsername(profile.username);
                      setIsEditingProfile(true);
                    }}
                    className="mt-5 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-700 px-6 py-2.5 font-sans text-xs font-bold text-white transition-all hover:bg-neutral-850 active:scale-95 shadow-[0_2px_8px_rgba(0,0,0,0.4)]"
                  >
                    Edit Profile
                  </button>

                  <input
                    type="file"
                    ref={profileFileRef}
                    accept="image/png, image/jpeg, image/jpg, image/webp, image/bmp, image/tiff"
                    className="hidden"
                    onChange={handleProfileAvatarChange}
                  />
                </div>

                {/* Saved Local Deck Items / Device Photos Header */}
                <div className="border-t border-neutral-900 pt-8 mt-4.5 mb-6">
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-brand-velvet" />
                    <h2 className="font-display text-sm font-bold text-brand-cream uppercase tracking-wider">
                      Saved to Device
                    </h2>
                  </div>
                  <p className="font-sans text-neutral-500 text-[11px] mt-1 italic">
                    High speed cached downloads on your virtual phone catalog.
                  </p>
                </div>

                {galleryPins.length > 0 ? (
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
                    {galleryPins.map((pin) => (
                      <div
                        key={pin.id}
                        onClick={() => setSelectedPin(pin)}
                        className="group relative cursor-pointer overflow-hidden rounded-xl border border-neutral-850 bg-neutral-950 transition-all hover:scale-[1.01] hover:shadow-lg"
                      >
                        <CachedImage
                          src={pin.url}
                          width={pin.width}
                          height={pin.height}
                          alt={pin.title}
                        />
                        <div className="absolute inset-0 bg-black/60 p-3 opacity-0 transition-opacity duration-200 group-hover:opacity-100 flex flex-col justify-between">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setDownloadedIds((prev) => prev.filter((id) => id !== pin.id));
                              triggerNotification('Removed file reference from phone gallery index.', 'info');
                            }}
                            className="self-end flex h-7 w-7 items-center justify-center rounded-full bg-neutral-900 text-neutral-400 hover:text-red-500 transition-colors"
                            title="Remove placeholder from Gallery"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>

                          <div>
                            <span className="block truncate font-sans text-[11px] font-bold text-white">
                              {pin.title}
                            </span>
                            <span className="block font-mono text-[9px] text-brand-velvet font-bold uppercase tracking-wider mt-1">
                              Saved to Disk
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-24 text-center rounded-2xl border border-dashed border-neutral-900 p-6 bg-neutral-950/20">
                    <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-neutral-900 text-neutral-550">
                      <ImageIcon className="h-6 w-6" />
                    </div>
                    <p className="font-sans text-sm font-semibold text-neutral-300">Your saved captures are empty</p>
                    <p className="font-sans text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
                      Initiate a secure image download by tapping the download button on any pin to append it here.
                    </p>
                  </div>
                )}
              </div>
            )}
          </>
        </motion.div>
      )}
    </AnimatePresence>
  </main>

      {/* Persistent Bottom Navigation Drawer: Identical to Pinterest Android */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-black/95 border-t border-neutral-900 py-2.5 pb-4 px-6 flex items-center justify-around select-none">
        
        {/* Home Feed Button */}
        <button
          onClick={() => {
            setSelectedPin(null);
            setActiveTab('home');
          }}
          className={`flex flex-col items-center gap-1 transition-all active:scale-90 select-none cursor-pointer ${
            activeTab === 'home' && !selectedPin ? 'text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <Home className={`h-5.5 w-5.5 ${activeTab === 'home' && !selectedPin ? 'text-red-500' : ''}`} />
          <span className="font-sans text-[10px] tracking-tight">Feed</span>
        </button>

        {/* Upload Button */}
        <button
          onClick={() => {
            setSelectedPin(null);
            setActiveTab('upload');
          }}
          className={`flex flex-col items-center gap-1 transition-all active:scale-90 select-none cursor-pointer ${
            activeTab === 'upload' ? 'text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <PlusCircle className={`h-5.5 w-5.5 ${activeTab === 'upload' ? 'text-red-500' : ''}`} />
          <span className="font-sans text-[10px] tracking-tight">Create</span>
        </button>

        {/* Dynamic Board Collections view */}
        <button
          onClick={() => {
            setSelectedPin(null);
            setActiveTab('boards');
          }}
          className={`flex flex-col items-center gap-1 transition-all active:scale-90 select-none cursor-pointer ${
            activeTab === 'boards' ? 'text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <FolderHeart className={`h-5.5 w-5.5 ${activeTab === 'boards' ? 'text-red-500' : ''}`} />
          <span className="font-sans text-[10px] tracking-tight">Boards</span>
        </button>

        {/* Personal Profile Tab */}
        <button
          onClick={() => {
            setSelectedPin(null);
            setActiveTab('gallery');
          }}
          className={`flex flex-col items-center gap-1 transition-all active:scale-90 select-none cursor-pointer ${
            activeTab === 'gallery' ? 'text-white font-bold' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <div className="relative">
            <img
              src={profile.avatar}
              alt="Profile avatar"
              referrerPolicy="no-referrer"
              className={`h-[22px] w-[22px] rounded-full object-cover border transition-all ${
                activeTab === 'gallery' ? 'border-brand-velvet ring-2 ring-brand-velvet/40' : 'border-neutral-700'
              }`}
            />
            {downloadedIds.length > 0 && (
              <span className="absolute -top-1 -right-1.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-brand-velvet text-[8px] font-bold text-white font-mono scale-90 shadow-[0_1px_4px_rgba(0,0,0,0.5)] border border-black">
                {downloadedIds.length}
              </span>
            )}
          </div>
          <span className="font-sans text-[10px] tracking-tight">Profile</span>
        </button>
      </nav>

      {/* Save pin to board bottom-sheet dialog node */}
      {savingPinForBoard && (
        <BoardSelectorModal
          pin={savingPinForBoard}
          boards={boards}
          onClose={() => setSavingPinForBoard(null)}
          onSaveToBoard={handleSaveToBoard}
          onCreateBoard={handleCreateNewBoard}
        />
      )}

      {/* Edit Profile Modal Dialog */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md select-none transition-all">
          <div className="w-full max-w-sm rounded-[24px] bg-[#121212] border border-neutral-850 p-6 shadow-[0_12px_40px_rgba(0,0,0,0.8)] animate-in fade-in zoom-in-95 duration-200">
            <div className="text-center mb-6">
              <h2 className="font-display text-lg font-black text-white tracking-wider uppercase">
                Edit Profile
              </h2>
              <p className="font-sans text-[11px] text-neutral-500 mt-1">
                Customize your layout design identity
              </p>
            </div>

            {/* Profile Avatar Picker */}
            <div className="flex flex-col items-center gap-2 mb-6">
              <div 
                onClick={() => profileFileRef.current?.click()}
                className="group relative h-20 w-20 rounded-full overflow-hidden border border-neutral-800 cursor-pointer shadow-inner bg-neutral-900"
              >
                <img
                  src={profile.avatar}
                  alt={profile.fullName}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <span className="text-[9px] font-sans font-bold text-white uppercase tracking-wider text-center px-1">
                    Tap to Choose
                  </span>
                </div>
              </div>
              <span className="font-sans text-[10px] text-neutral-400 font-medium">
                Tap photo to replace avatar
              </span>
            </div>

            {/* Editing Inputs form */}
            <div className="space-y-4 mb-6">
              {/* Full Name field */}
              <div>
                <label className="block font-sans text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="Your visual name"
                  value={editFullName}
                  onChange={(e) => setEditFullName(e.target.value)}
                  className="w-full rounded-xl bg-neutral-950 border border-neutral-850 p-3 font-sans text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-neutral-700 transition-colors"
                />
              </div>

              {/* Username field */}
              <div>
                <label className="block font-sans text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-1.5">
                  Username
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 inset-y-0 flex items-center text-neutral-500 font-mono text-sm leading-none pointer-events-none">
                    @
                  </span>
                  <input
                    type="text"
                    placeholder="creator_handle"
                    value={editUsername}
                    onChange={(e) => {
                      // format username input (sanitize spaces etc)
                      const clean = e.target.value
                        .toLowerCase()
                        .replace(/[^a-z0-9_.-]/g, '');
                      setEditUsername(clean);
                    }}
                    className="w-full rounded-xl bg-neutral-950 border border-neutral-850 py-3 pl-8 pr-3 font-sans text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-neutral-700 transition-colors font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-2.5">
              <button
                onClick={() => setIsEditingProfile(false)}
                className="flex-1 rounded-full bg-neutral-900 border border-neutral-800 hover:border-neutral-750 py-2.5 font-sans text-xs font-bold text-neutral-300 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const cleanName = editFullName.trim();
                  const cleanUser = editUsername.trim();

                  if (!cleanName) {
                    triggerNotification('Full Name is required.', 'error');
                    return;
                  }
                  if (!cleanUser) {
                    triggerNotification('Username is required.', 'error');
                    return;
                  }

                  setProfile((prev: any) => ({
                    ...prev,
                    fullName: cleanName,
                    username: cleanUser,
                  }));

                  triggerNotification('Local design profile successfully synced!', 'success');
                  setIsEditingProfile(false);
                }}
                className="flex-1 rounded-full bg-brand-velvet hover:bg-brand-velvet-hover py-2.5 font-sans text-xs font-bold text-white transition-all shadow-[0_4px_12px_rgba(139,0,0,0.4)] active:scale-95"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
