/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ImagePin {
  id: string;
  url: string;
  title: string;
  description: string;
  author: string;
  authorAvatar: string;
  width: number;
  height: number;
  likes: number;
  boardIds: string[]; // Pin can belong to multiple boards
  downloadCount: number;
  commentsCount: number;
  isLikedByUser?: boolean;
  tags: string[];
}

export interface Board {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'downloading';
  progress?: number; // 0 to 100
  retryCount?: number;
}

export interface PinComment {
  id: string;
  pinId: string;
  author: string;
  authorAvatar: string;
  text: string;
  timestamp: string;
}
