/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Memory Cache for instant sync renders of already cached URLs in session
const memoryCache = new Map<string, string>();

/**
 * High-performance image storage and caching engine.
 * Mimics Android's native image caching (Coil / Glide / Jetpack Compose AsyncImage).
 * Uses Web Cache API for persistent disk caching, and Map for memory caching.
 */
export async function getCachedImageUrl(url: string, signal?: AbortSignal): Promise<string> {
  // 1. Memory Check (Fastest - standard React memory references)
  if (memoryCache.has(url)) {
    return memoryCache.get(url)!;
  }

  // Check if Cache API is supported (e.g., inside sandboxed iframes)
  const isCacheSupported = typeof window !== 'undefined' && 'caches' in window;
  if (!isCacheSupported) {
    return url;
  }

  try {
    const cache = await caches.open('vibe-deck-image-cache-v1');
    const cachedResponse = await cache.match(url);

    if (cachedResponse) {
      // 2. Disk Cache Hit
      const blob = await cachedResponse.blob();
      const objectUrl = URL.createObjectURL(blob);
      memoryCache.set(url, objectUrl);
      return objectUrl;
    }

    // 3. Cache Miss - Fetch asynchronously
    // We add CORS mode so we can access the underlying binary data securely
    const response = await fetch(url, {
      method: 'GET',
      mode: 'cors',
      credentials: 'omit',
      signal
    });

    if (!response.ok) {
      throw new Error(`Fetch failed: ${response.statusText}`);
    }

    // Clone response before storing, as body reader can only be used once
    await cache.put(url, response.clone());

    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    memoryCache.set(url, objectUrl);
    return objectUrl;
  } catch (error) {
    // Elegant resilience: fallback right away to direct URL if CORS or network blocks fetch
    // Web browsers are highly optimized for direct image tags as a backup!
    return url;
  }
}

/**
 * Preloads an entire batch of URLs into the cache.
 * Emulates Android's high speed prefetching.
 */
export async function prefetchImages(urls: string[]): Promise<void> {
  const isCacheSupported = typeof window !== 'undefined' && 'caches' in window;
  if (!isCacheSupported) return;

  try {
    const cache = await caches.open('vibe-deck-image-cache-v1');
    await Promise.all(
      urls.map(async (url) => {
        try {
          const matched = await cache.match(url);
          if (!matched) {
            const response = await fetch(url, { mode: 'cors', credentials: 'omit' });
            if (response.ok) {
              await cache.put(url, response);
            }
          }
        } catch {
          // Silent catch for prefetch errors to prevent breaking app
        }
      })
    );
  } catch {
    // Ignore overall cache API failures
  }
}

/**
 * Clears both memory and disk image caches.
 */
export async function clearImageCache(): Promise<void> {
  memoryCache.clear();
  if (typeof window !== 'undefined' && 'caches' in window) {
    await caches.delete('vibe-deck-image-cache-v1');
  }
}
