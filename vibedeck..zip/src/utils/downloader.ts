/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

interface DownloadProgressCallback {
  onProgress?: (progress: number) => void;
  onRetry?: (retryCount: number) => void;
  onSuccess?: (localUrl: string) => void;
  onFailure?: (error: Error) => void;
}

/**
 * Robust image download client modeled on native Android Media Store & background Workers.
 * Implements:
 * 1. Exponential backoff retry logic (up to 3 retries)
 * 2. Real-time progress monitoring
 * 3. Graceful fallback & diagnostics
 * 4. Browser File System file generation (acting as simulated MediaStore Gallery saving)
 */
export async function downloadImageWithRetries(
  url: string,
  fileName: string,
  callbacks?: DownloadProgressCallback,
  maxRetries = 3
): Promise<Blob> {
  let attempt = 0;
  let delay = 1000; // start with 1 second backoff

  while (attempt <= maxRetries) {
    try {
      if (attempt > 0) {
        callbacks?.onRetry?.(attempt);
        // Wait with backoff delay
        await new Promise((resolve) => setTimeout(resolve, delay));
        delay *= 1.5; // exponentially scale delay
      }

      const controller = new AbortController();
      const signal = controller.signal;

      // Start the actual fetch request
      const response = await fetch(url, {
        method: 'GET',
        mode: 'cors',
        credentials: 'omit',
        signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP Error Status: ${response.status}`);
      }

      // To read progress, we must use response.body and headers
      const contentLengthHeader = response.headers.get('content-length');
      const totalBytes = contentLengthHeader ? parseInt(contentLengthHeader, 10) : 0;
      
      const reader = response.body?.getReader();
      if (!reader) {
        // Fallback for bodies without reader support
        const blob = await response.blob();
        callbacks?.onProgress?.(100);
        triggerBrowserDownload(blob, fileName);
        return blob;
      }

      let receivedBytes = 0;
      const chunks: Uint8Array[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        chunks.push(value);
        receivedBytes += value.length;

        if (totalBytes > 0) {
          const progress = Math.min(Math.round((receivedBytes / totalBytes) * 100), 99);
          callbacks?.onProgress?.(progress);
        } else {
          // Fallback approximate progress calculation
          callbacks?.onProgress?.(50);
        }
      }

      // Merge chunks into a final Blob
      const blob = new Blob(chunks, { type: response.headers.get('content-type') || 'image/jpeg' });
      callbacks?.onProgress?.(100);

      // Trigger standard browser download
      triggerBrowserDownload(blob, fileName);

      const cachedLocalUrl = URL.createObjectURL(blob);
      callbacks?.onSuccess?.(cachedLocalUrl);
      return blob;

    } catch (error: any) {
      attempt++;
      console.warn(`[Downloader] Attempt ${attempt} failed: ${error?.message || error}`);

      if (attempt > maxRetries) {
        const finalError = new Error(error?.message || 'Download failed after maximum attempts');
        callbacks?.onFailure?.(finalError);
        throw finalError;
      }
    }
  }

  throw new Error('Unreachable state reached in downloader');
}

/**
 * Triggers the device download action.
 * Maps to saving inside Android MediaStore.Images.Media.insertImage
 */
function triggerBrowserDownload(blob: Blob, fileName: string): void {
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // Clean up object URL after brief delay
  setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
}
