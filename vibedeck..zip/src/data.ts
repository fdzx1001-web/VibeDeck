/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ImagePin, Board, PinComment } from './types';

export const INITIAL_BOARDS: Board[] = [
  { id: '1', name: 'Aesthetic Architectures', description: 'Stunning structural designs and minimalist brutalism', createdAt: '2026-01-01' },
  { id: '2', name: 'Indie Dev Workspaces', description: 'Clean desk setups, mechanical keyboards, and dark mode screens', createdAt: '2026-02-15' },
  { id: '3', name: 'Atmospheric Moody Vibe', description: 'High contrast shadows, misty pine forests, and dark skylines', createdAt: '2026-03-10' },
  { id: '4', name: 'Wallpapers', description: 'Geometric minimalism, graphic layouts, and typography', createdAt: '2026-04-01' },
];

export const INITIAL_PINS: ImagePin[] = [];

export const INITIAL_COMMENTS: PinComment[] = [
  {
    id: 'c_1',
    pinId: 'pin_1',
    author: 'Sarah Jenkins',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    text: 'Tadao Ando vibes! The concrete looks so sharp and clean.',
    timestamp: '2 hours ago'
  },
  {
    id: 'c_2',
    pinId: 'pin_1',
    author: 'Marcus Aurelius',
    authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    text: 'Is this real or a 3D render? The lighting is immaculate.',
    timestamp: '5 hours ago'
  },
  {
    id: 'c_3',
    pinId: 'pin_3',
    author: 'Linus Keyboard',
    authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    text: 'What keycaps are those? Looking for an identical color profile!',
    timestamp: '1 day ago'
  }
];
