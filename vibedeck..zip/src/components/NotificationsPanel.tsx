/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppNotification } from '../types';
import { CheckCircle2, AlertTriangle, AlertCircle, Loader2, Download, X } from 'lucide-react';

interface NotificationsPanelProps {
  notifications: AppNotification[];
  onDismiss: (id: string) => void;
}

/**
 * Toast notification bar mimicking Android system heads-up notifications.
 * Handles progress visualization, retry diagnostics, and automatic fading out.
 */
export const NotificationsPanel: React.FC<NotificationsPanelProps> = ({
  notifications,
  onDismiss
}) => {
  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-20 right-4 z-50 flex flex-col gap-2.5 max-w-[calc(100vw-32px)] w-80 sm:bottom-6">
      {notifications.map((notif) => {
        let icon = <Loader2 className="h-4 w-4 animate-spin text-neutral-400" />;
        let bgClass = 'bg-neutral-900 border-neutral-800';
        let textClass = 'text-neutral-200';

        switch (notif.type) {
          case 'success':
            icon = <CheckCircle2 className="h-4 w-4 text-emerald-500" />;
            bgClass = 'bg-emerald-950/90 border-emerald-900/50 backdrop-blur-md';
            textClass = 'text-emerald-250';
            break;
          case 'error':
            icon = <AlertCircle className="h-4 w-4 text-red-500" />;
            bgClass = 'bg-red-950/90 border-red-900/50 backdrop-blur-md';
            textClass = 'text-red-300';
            break;
          case 'warning':
            icon = <AlertTriangle className="h-4 w-4 text-amber-550" />;
            bgClass = 'bg-amber-950/90 border-amber-900/50 backdrop-blur-md';
            textClass = 'text-amber-250';
            break;
          case 'downloading':
            icon = <Download className="h-4 w-4 text-blue-500 animate-bounce" />;
            bgClass = 'bg-neutral-900 border-neutral-750 backdrop-blur-md';
            textClass = 'text-neutral-200';
            break;
        }

        return (
          <div
            key={notif.id}
            className={`flex flex-col rounded-xl border p-4 shadow-xl transition-all duration-300 animate-slide-in ${bgClass}`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="flex h-5 w-5 items-center justify-center shrink-0">
                  {icon}
                </div>
                <p className={`font-sans text-xs font-semibold ${textClass}`}>
                  {notif.message}
                </p>
              </div>
              <button
                onClick={() => onDismiss(notif.id)}
                className="text-neutral-500 hover:text-white shrink-0 active:scale-90"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Simulated background cellular progress bar for in-flight requests */}
            {notif.type === 'downloading' && typeof notif.progress !== 'undefined' && (
              <div className="mt-3">
                <div className="flex justify-between text-[10px] font-mono text-neutral-450 mb-1">
                  <span>Downloader Worker</span>
                  <span>{notif.progress}%</span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-neutral-850">
                  <div
                    className="h-full bg-blue-600 rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${notif.progress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Backoff retry indicator bar */}
            {notif.retryCount && notif.retryCount > 0 && (
              <div className="mt-1.5 flex items-center gap-1.5 pl-7">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-amber-500 animate-ping" />
                <span className="font-mono text-[9px] text-amber-500 uppercase tracking-widest font-semibold">
                  Auto-Retrying (Attempt {notif.retryCount}/3)
                </span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
