/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Board, ImagePin } from '../types';
import { X, FolderPlus, Plus, Check } from 'lucide-react';

interface BoardSelectorModalProps {
  pin: ImagePin;
  boards: Board[];
  onClose: () => void;
  onSaveToBoard: (boardId: string) => void;
  onCreateBoard: (boardName: string) => void;
}

/**
 * Android-inspired Bottom Sheet Dialog for Saving Pins to Boards.
 * Features fluid board searching, quick board creation, and active multi-selection.
 */
export const BoardSelectorModal: React.FC<BoardSelectorModalProps> = ({
  pin,
  boards,
  onClose,
  onSaveToBoard,
  onCreateBoard
}) => {
  const [newBoardName, setNewBoardName] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredBoards = boards.filter((b) =>
    b.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubmitNewBoard = (e: React.FormEvent) => {
    e.preventDefault();
    if (newBoardName.trim()) {
      onCreateBoard(newBoardName.trim());
      setNewBoardName('');
      setShowCreateForm(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 backdrop-blur-sm sm:items-center">
      {/* Tap outside to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Sheet Content container with 12dp rounded corners */}
      <div className="relative z-10 w-full max-w-md rounded-t-[20px] bg-neutral-900 border-t border-neutral-800 p-6 shadow-2xl animate-slide-up sm:rounded-[16px] sm:border">
        {/* Pull bar for Android bottom sheet visual cue */}
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-neutral-700 sm:hidden" />

        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-sans text-lg font-bold text-white">Save to board</h3>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Selected Pin Mini Summary */}
        <div className="mb-4 flex items-center gap-3 rounded-xl bg-neutral-850 p-3">
          <img
            src={pin.url}
            alt={pin.title}
            referrerPolicy="no-referrer"
            className="h-14 w-14 rounded-lg object-cover"
          />
          <div className="min-w-0">
            <h4 className="truncate font-sans text-sm font-semibold text-neutral-200">
              {pin.title}
            </h4>
            <p className="truncate font-sans text-xs text-neutral-450">
              by {pin.author}
            </p>
          </div>
        </div>

        {/* Board Search Field */}
        {!showCreateForm && (
          <input
            type="text"
            placeholder="Search boards..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="mb-4 w-full rounded-full bg-neutral-800 px-4 py-2.5 font-sans text-sm text-white placeholder-neutral-500 outline-none focus:ring-1 focus:ring-neutral-600 focus:bg-neutral-800/80 transition-all"
          />
        )}

        {/* Playlists/Boards List container */}
        <div className="max-h-60 overflow-y-auto pr-1">
          {showCreateForm ? (
            <form onSubmit={handleSubmitNewBoard} className="space-y-4 py-2">
              <div>
                <label className="mb-1.5 block font-sans text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                  Board Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Summer Minimalism"
                  value={newBoardName}
                  onChange={(e) => setNewBoardName(e.target.value)}
                  autoFocus
                  className="w-full rounded-xl bg-neutral-850 border border-neutral-800 px-4 py-3 font-sans text-sm text-white outline-none focus:border-neutral-650 transition-colors"
                />
              </div>
              <div className="flex gap-3 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="rounded-full px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newBoardName.trim()}
                  className="rounded-full bg-brand-velvet px-5 py-2 text-xs font-semibold text-brand-cream transition-opacity disabled:opacity-50 hover:bg-brand-velvet-hover shadow-[0_4px_10px_rgba(139,0,0,0.4)] cursor-pointer"
                >
                  Create Board
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-1.5">
              {filteredBoards.map((board) => {
                const isSaved = pin.boardIds.includes(board.id);
                return (
                  <button
                    key={board.id}
                    onClick={() => onSaveToBoard(board.id)}
                    className="flex w-full items-center justify-between rounded-xl p-3 text-left transition-all hover:bg-neutral-800/60 active:bg-neutral-800"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-neutral-800 text-neutral-400">
                        <FolderPlus className="h-5 w-5 text-neutral-400" />
                      </div>
                      <div>
                        <span className="block font-sans text-sm font-semibold text-neutral-250">
                          {board.name}
                        </span>
                        <span className="block font-sans text-[11px] text-neutral-500">
                          {board.description || 'Virtual Board'}
                        </span>
                      </div>
                    </div>

                    <div
                      className={`flex h-6 w-6 items-center justify-center rounded-full transition-all ${
                        isSaved
                          ? 'bg-brand-velvet text-brand-cream shadow-[0_2px_8px_rgba(139,0,0,0.5)]'
                          : 'border border-neutral-700 text-transparent hover:border-neutral-500'
                      }`}
                    >
                      <Check className="h-3.5 w-3.5" />
                    </div>
                  </button>
                );
              })}

              {filteredBoards.length === 0 && (
                <div className="py-8 text-center text-xs text-neutral-500">
                  No boards found. Create a new one below to begin.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Quick Creator Button Footer */}
        {!showCreateForm && (
          <button
            onClick={() => setShowCreateForm(true)}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-neutral-850 py-3 font-sans text-xs font-bold text-neutral-400 hover:border-neutral-700 hover:text-white transition-colors"
          >
            <Plus className="h-4 w-4" />
            <span>Create new Board</span>
          </button>
        )}
      </div>
    </div>
  );
};
