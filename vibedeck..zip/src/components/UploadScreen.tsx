/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { ImagePin } from '../types';
import { UploadCloud, CheckCircle, Smartphone, AlertTriangle, Image as ImageIcon } from 'lucide-react';

interface UploadScreenProps {
  onAddPin: (newPin: ImagePin) => void;
  showSuccessToast: (msg: string) => void;
  showErrorToast: (msg: string) => void;
  onNavigateHome: () => void;
}

/**
 * Image-only Upload & Optimizer interface representing strict Android constraints.
 * Implements:
 * 1. Native click + drag photo picking.
 * 2. Mandatory image-only format validation (rejecting any video files instantly).
 * 3. Client-side Canvas Compression engine to minimize memory & storage layouts.
 * 4. Compression stats telemetry visualizer.
 */
export const UploadScreen: React.FC<UploadScreenProps> = ({
  onAddPin,
  showSuccessToast,
  showErrorToast,
  onNavigateHome
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [author, setAuthor] = useState('Local Creator');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationStats, setOptimizationStats] = useState<{
    originalSize: string;
    compressedSize: string;
    savings: string;
    compressedBase64: string;
    width: number;
    height: number;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Parse file and execute block/acceptance validation (Blocks videos strictly)
  const processFile = (file: File) => {
    if (!file) return;

    const fileName = file.name.toLowerCase();
    
    // Strict video prevention check - block mp4, mov, m4v and standard video MIME types
    const isVideo = fileName.endsWith('.mp4') || 
                    fileName.endsWith('.mov') || 
                    fileName.endsWith('.m4v') || 
                    file.type.startsWith('video/');
    
    if (isVideo) {
      showErrorToast('Selected file is a video. Videos are strictly blocked to preserve high speed performance!');
      setSelectedFile(null);
      setPreviewUrl(null);
      setOptimizationStats(null);
      return;
    }

    // Supported professional Pinterest image formats
    const isSupportedImage = file.type.startsWith('image/') || 
                              ['.png', '.jpeg', '.jpg', '.webp', '.bmp', '.tiff', '.tif'].some(ext => fileName.endsWith(ext));

    if (!isSupportedImage) {
      showErrorToast('Unsupported format. Please upload professional images (JPEG, PNG, WEBP, BMP, TIFF) to join the deck.');
      setSelectedFile(null);
      setPreviewUrl(null);
      setOptimizationStats(null);
      return;
    }

    setSelectedFile(file);
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    setOptimizationStats(null); // Clear previous stats

    // Run automatic compression
    compressAndOptimizeImage(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Background Image Compression Pipeline using Web standard equivalent of Android BitmapFactory
  const compressAndOptimizeImage = async (file: File) => {
    setIsOptimizing(true);
    
    const fallbackReader = () => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            setIsOptimizing(false);
            return;
          }

          // Preserve ultra-crisp high-density details by allowing up to 2048px maximum bound sizing for 4K designs
          const MAX_DIMENSION = 2048;
          let imgWidth = img.width;
          let imgHeight = img.height;

          if (imgWidth > MAX_DIMENSION || imgHeight > MAX_DIMENSION) {
            if (imgWidth > imgHeight) {
              imgHeight = Math.round((imgHeight * MAX_DIMENSION) / imgWidth);
              imgWidth = MAX_DIMENSION;
            } else {
              imgWidth = Math.round((imgWidth * MAX_DIMENSION) / imgHeight);
              imgHeight = MAX_DIMENSION;
            }
          }

          canvas.width = imgWidth;
          canvas.height = imgHeight;

          // Enable high-quality drawing filters
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';

          ctx.drawImage(img, 0, 0, imgWidth, imgHeight);

          // Convert using 0.82 compression rating to preserve sharp 4K textures while cutting file footprints
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.82);

          const originalKBs = (file.size / 1024).toFixed(1);
          const compressedKBs = ((compressedBase64.length * 0.75) / 1024).toFixed(1);
          const percentSavings = (
            (1 - parseFloat(compressedKBs) / parseFloat(originalKBs)) *
            100
          ).toFixed(0);

          setOptimizationStats({
            originalSize: `${originalKBs} KB`,
            compressedSize: `${compressedKBs} KB`,
            savings: `${percentSavings}%`,
            compressedBase64,
            width: imgWidth,
            height: imgHeight,
          });
          setIsOptimizing(false);
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    };

    // Use modern BitmapFactory-like background image decoder (createImageBitmap) to keep main thread completely free of lag
    if (typeof window !== 'undefined' && 'createImageBitmap' in window) {
      try {
        const imageBitmap = await createImageBitmap(file);
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          imageBitmap.close();
          fallbackReader();
          return;
        }

        // Preserve ultra-crisp high-density details by allowing up to 2048px bounds for clean 4K wallpapers
        const MAX_DIMENSION = 2048;
        let imgWidth = imageBitmap.width;
        let imgHeight = imageBitmap.height;

        if (imgWidth > MAX_DIMENSION || imgHeight > MAX_DIMENSION) {
          if (imgWidth > imgHeight) {
            imgHeight = Math.round((imgHeight * MAX_DIMENSION) / imgWidth);
            imgWidth = MAX_DIMENSION;
          } else {
            imgWidth = Math.round((imgWidth * MAX_DIMENSION) / imgHeight);
            imgHeight = MAX_DIMENSION;
          }
        }

        canvas.width = imgWidth;
        canvas.height = imgHeight;

        // Enable high-quality drawing filters
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(imageBitmap, 0, 0, imgWidth, imgHeight);

        // Convert using 0.82 compression rating to preserve sharp 4K textures while cutting file footprints
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.82);

        const originalKBs = (file.size / 1024).toFixed(1);
        const compressedKBs = ((compressedBase64.length * 0.75) / 1024).toFixed(1);
        const percentSavings = (
          (1 - parseFloat(compressedKBs) / parseFloat(originalKBs)) *
          100
        ).toFixed(0);

        setOptimizationStats({
          originalSize: `${originalKBs} KB`,
          compressedSize: `${compressedKBs} KB`,
          savings: `${percentSavings}%`,
          compressedBase64,
          width: imgWidth,
          height: imgHeight,
        });
        setIsOptimizing(false);
        imageBitmap.close();
      } catch (err) {
        console.warn('createImageBitmap background error, using fallback:', err);
        fallbackReader();
      }
    } else {
      fallbackReader();
    }
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      showErrorToast('Please enter a title for your architectural pin.');
      return;
    }

    if (!optimizationStats) {
      showErrorToast('Optimizing and compressing is in progress. Please wait.');
      return;
    }

    const keywords = (title.toLowerCase() + " " + description.toLowerCase()).split(/\W+/);
    const availableTags = ["streetwear", "dark_academia", "anime_core", "minimalist", "brutalist", "setup", "nature", "nordic", "editorial", "abstract", "pastel"];
    const matchedTags = availableTags.filter(tag => keywords.includes(tag) || (tag === "dark_academia" && (keywords.includes("dark") || keywords.includes("academia"))));
    const finalTags = matchedTags.length > 0 ? matchedTags : ['minimalist'];

    // Assembly PIN schema
    const newPin: ImagePin = {
      id: `local_pin_${Date.now()}`,
      url: optimizationStats.compressedBase64, // Real compressed URL payload
      title: title.trim(),
      description: description.trim() || 'A locally optimized aesthetic capture.',
      author: author.trim() || 'Local Creator',
      authorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      width: optimizationStats.width,
      height: optimizationStats.height,
      likes: 0,
      boardIds: [], // User can choose to add to boards from home feed or details view
      downloadCount: 0,
      commentsCount: 0,
      isLikedByUser: false,
      tags: finalTags,
    };

    onAddPin(newPin);
    showSuccessToast('Image optimized, compressed, and published to local feed successfully!');
    onNavigateHome();
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 pb-32">
      <div className="mb-8">
        <h2 className="font-sans text-2xl font-black text-white">Create Pin</h2>
        <p className="font-sans text-xs text-neutral-450 mt-1">
          Perform high-performance upload. Audio and videos are strictly rejected.
        </p>
      </div>

      <form onSubmit={handlePublish} className="grid grid-cols-1 gap-8 md:grid-cols-2">
        {/* Upload Stage / Drag Panel Zone */}
        <div className="flex flex-col gap-4">
          <label className="block font-sans text-xs font-semibold text-neutral-400 uppercase tracking-wider">
            Add Image Asset
          </label>

          <div
            id="drag-and-drop-container"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={onButtonClick}
            className={`relative flex min-h-[340px] cursor-pointer flex-col items-center justify-center rounded-[24px] border-2 border-dashed p-6 text-center transition-all ${
              dragActive
                ? 'border-brand-velvet bg-neutral-900'
                : previewUrl
                ? 'border-neutral-800 bg-neutral-950/40 p-0 overflow-hidden'
                : 'border-neutral-800 bg-neutral-950 hover:border-neutral-700'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png, image/jpeg, image/jpg, image/webp, image/bmp, image/tiff, image/gif"
              className="hidden"
              onChange={handleChange}
            />

            {previewUrl ? (
              <div className="group relative h-full w-full">
                <img
                  src={previewUrl}
                  alt="Upload preview"
                  referrerPolicy="no-referrer"
                  className="max-h-[380px] w-full object-cover rounded-[22px]"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 transition-opacity group-hover:opacity-100 rounded-[22px]">
                  <p className="font-sans text-xs font-bold text-white">Tap to change image</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-neutral-900 text-neutral-450 shadow-inner">
                  <UploadCloud className="h-7 w-7" />
                </div>
                <div>
                  <p className="font-sans text-sm font-semibold text-neutral-200">
                    Choose a file or drag & drop
                  </p>
                  <p className="font-sans text-[11px] text-neutral-500 mt-1 max-w-[200px]">
                    Supported formats: JPEG, PNG, WEBP, BMP, TIFF. Videos are strictly blocked.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Canvas Compression Telemetry Output */}
          {selectedFile && (
            <div className="rounded-2xl border border-neutral-850 bg-neutral-950/60 p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5 font-sans text-xs font-bold text-neutral-300">
                  <Smartphone className="h-3.5 w-3.5 text-red-500" />
                  <span>Space Saver Telemetry</span>
                </span>
                {isOptimizing ? (
                  <span className="animate-pulse font-mono text-[10px] text-red-500 font-semibold uppercase">
                    Optimizing...
                  </span>
                ) : (
                  <span className="flex items-center gap-1 rounded bg-red-950 px-2 py-0.5 font-mono text-[9px] font-bold text-red-400 border border-red-900/40">
                    <CheckCircle className="h-2.5 w-2.5" />
                    <span>COMPRESSED</span>
                  </span>
                )}
              </div>

              {isOptimizing ? (
                <div className="space-y-2 py-1">
                  <div className="h-4 w-3/4 animate-pulse rounded bg-neutral-900" />
                  <div className="h-4 w-1/2 animate-pulse rounded bg-neutral-900" />
                </div>
              ) : (
                optimizationStats && (
                  <div className="grid grid-cols-3 gap-2 py-1">
                    <div className="rounded-lg bg-neutral-900 p-2.5 text-center">
                      <span className="block font-mono text-[10px] text-neutral-500 uppercase">Original</span>
                      <span className="font-sans text-xs font-semibold text-neutral-300">
                        {optimizationStats.originalSize}
                      </span>
                    </div>
                    <div className="rounded-lg bg-neutral-900 p-2.5 text-center">
                      <span className="block font-mono text-[10px] text-neutral-500 uppercase">Optimized</span>
                      <span className="font-sans text-xs font-bold text-red-400">
                        {optimizationStats.compressedSize}
                      </span>
                    </div>
                    <div className="rounded-lg bg-red-950/40 border border-red-900/20 p-2.5 text-center">
                      <span className="block font-mono text-[10px] text-red-400 uppercase">Saved</span>
                      <span className="font-sans text-xs font-bold text-emerald-400">
                        -{optimizationStats.savings}
                      </span>
                    </div>
                  </div>
                )
              )}
            </div>
          )}
        </div>

        {/* Metadata Details Entry Panel */}
        <div className="flex flex-col justify-between whitespace-normal">
          <div className="space-y-5">
            <div>
              <label className="mb-1.5 block font-sans text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                Title
              </label>
              <input
                type="text"
                placeholder="Title your layout design..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-xl bg-neutral-900 border border-neutral-800 px-4 py-3 font-sans text-sm text-white placeholder-neutral-550 outline-none focus:border-neutral-600 transition-colors"
                maxLength={60}
              />
            </div>

            <div>
              <label className="mb-1.5 block font-sans text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                Description
              </label>
              <textarea
                placeholder="Inject some atmospheric backstory or design notes here..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-28 w-full resize-none rounded-xl bg-neutral-900 border border-neutral-800 px-4 py-3 font-sans text-sm text-white placeholder-neutral-550 outline-none focus:border-neutral-600 transition-colors"
                maxLength={200}
              />
            </div>

            <div>
              <label className="mb-1.5 block font-sans text-xs font-semibold text-neutral-400 uppercase tracking-wider">
                Artist / Studio Signature
              </label>
              <input
                type="text"
                placeholder="Your Name / Handle"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full rounded-xl bg-neutral-900 border border-neutral-800 px-4 py-3 font-sans text-sm text-white placeholder-neutral-550 outline-none focus:border-neutral-600 transition-colors"
                maxLength={40}
              />
            </div>
          </div>

          <div className="pt-6">
            <button
              type="submit"
              disabled={isOptimizing || !selectedFile}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-brand-velvet py-3.5 font-sans text-sm font-bold text-brand-cream transition-opacity disabled:opacity-40 hover:bg-brand-velvet-hover active:scale-98 shadow-[0_4px_12px_rgba(139,0,0,0.5)]"
            >
              <ImageIcon className="h-4 w-4" />
              <span>Compress & Publish Pin</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
