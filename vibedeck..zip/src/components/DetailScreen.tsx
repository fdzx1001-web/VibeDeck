/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion } from 'motion/react';
import { ImagePin, PinComment } from '../types';
import { CachedImage } from './CachedImage';
import {
  ArrowLeft,
  Heart,
  Download,
  Bookmark,
  Send,
  MessageSquare,
  Sparkles,
  RefreshCw,
  Check
} from 'lucide-react';

interface DetailScreenProps {
  pin: ImagePin;
  pins: ImagePin[];
  comments: PinComment[];
  relatedPins: ImagePin[];
  onBack: () => void;
  onLikeToggle: (pinId: string) => void;
  onSaveBoardClick: (pin: ImagePin) => void;
  onDownloadClick: (pin: ImagePin) => void;
  onAddComment: (pinId: string, text: string) => void;
  onSelectPin: (pin: ImagePin) => void;
}

/**
 * Android-inspired Image Expander Detail Screen.
 * Implements:
 * 1. Fluid, distraction-free hero layout for focused visual viewing.
 * 2. Instant floating interaction shortcuts ("Download to Phone", "Save to Board").
 * 3. Reactive Likes toggle engine.
 * 4. Micro comment board.
 * 5. Explore section ("More like this") to continue smooth engagement.
 */
export const DetailScreen: React.FC<DetailScreenProps> = ({
  pin,
  pins,
  comments,
  relatedPins,
  onBack,
  onLikeToggle,
  onSaveBoardClick,
  onDownloadClick,
  onAddComment,
  onSelectPin
}) => {
  const [newCommentText, setNewCommentText] = useState('');
  const [isCommentsExpanded, setIsCommentsExpanded] = useState(true);
  
  // Local state for infinite scroll rendering
  const [visibleCount, setVisibleCount] = useState(4);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const loaderRef = useRef<HTMLDivElement | null>(null);

  // Compute pins sharing same aesthetic tags
  const overlappingPins = useMemo(() => {
    if (!pin.tags) return [];
    return pins
      .filter((p) => p.id !== pin.id && p.tags?.some((t) => pin.tags.includes(t)))
      .map((p) => {
        const overlapCount = p.tags.filter((t) => pin.tags.includes(t)).length;
        return { p, overlapCount };
      })
      .sort((a, b) => b.overlapCount - a.overlapCount)
      .map((item) => item.p);
  }, [pins, pin]);

  // Height-balanced partition logic for the 2-column Masonry sub-feed
  const [relatedCol1, rCol2] = useMemo(() => {
    const column1: ImagePin[] = [];
    const column2: ImagePin[] = [];
    let col1Height = 0;
    let col2Height = 0;

    overlappingPins.slice(0, visibleCount).forEach((item) => {
      const aspect = item.width / item.height;
      const approxHeight = 1 / aspect;

      if (col1Height <= col2Height) {
        column1.push(item);
        col1Height += approxHeight + 0.12;
      } else {
        column2.push(item);
        col2Height += approxHeight + 0.12;
      }
    });

    return [column1, column2];
  }, [overlappingPins, visibleCount]);

  // Monitor loader view in order to advance infinite scrolling state
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !isLoadingMore && visibleCount < overlappingPins.length) {
          setIsLoadingMore(true);
          setTimeout(() => {
            setVisibleCount((prev) => Math.min(prev + 4, overlappingPins.length));
            setIsLoadingMore(false);
          }, 600); // realistic ultra-fast cached renderer layout wait index
        }
      },
      { threshold: 0.1 }
    );

    const currentLoader = loaderRef.current;
    if (currentLoader) {
      observer.observe(currentLoader);
    }

    return () => {
      if (currentLoader) {
        observer.unobserve(currentLoader);
      }
    };
  }, [isLoadingMore, visibleCount, overlappingPins.length]);

  // Scroll to top when pin changes to support deep exploration clicks
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pin.id]);

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCommentText.trim()) {
      onAddComment(pin.id, newCommentText.trim());
      setNewCommentText('');
    }
  };

  const filteredComments = comments.filter((c) => c.pinId === pin.id);

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 pb-32">
      {/* Top Navigation Row */}
      <div className="mb-6 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex h-10 items-center justify-center gap-2 rounded-full bg-neutral-900 px-4 text-xs font-semibold text-neutral-300 hover:text-white hover:bg-neutral-800 active:scale-95 transition-all select-none"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Go Back</span>
        </button>

        <div className="flex gap-2">
          {/* Quick Save */}
          <button
            onClick={() => onSaveBoardClick(pin)}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-neutral-900 text-neutral-300 hover:text-white hover:bg-neutral-800 active:scale-95 transition-all"
            title="Save to Deck"
          >
            <Bookmark className="h-4 w-4" />
          </button>
          
          {/* Direct download with retries */}
          <button
            onClick={() => onDownloadClick(pin)}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-velvet text-brand-cream hover:bg-brand-velvet-hover active:scale-95 transition-all shadow-[0_4px_10px_rgba(139,0,0,0.5)]"
            title="Download to Device Gallery"
          >
            <Download className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Container Core Layout */}
      <div className="overflow-hidden rounded-[24px] border border-neutral-850 bg-neutral-950 shadow-2xl transition-all">
        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Hero Visual Block */}
          <div className="relative bg-neutral-900 flex items-center justify-center max-h-[85vh] overflow-hidden md:max-h-[750px] p-2">
            <motion.div 
              layoutId={`pin-image-container-${pin.id}`}
              transition={{ type: "spring", stiffness: 350, damping: 30 }}
              className="w-full h-full max-w-full relative flex items-center justify-center"
            >
              <CachedImage
                src={pin.url}
                width={pin.width}
                height={pin.height}
                alt={pin.title}
                className="max-h-[80vh] w-auto max-w-full object-contain rounded-2xl md:max-h-[700px]"
              />
            </motion.div>
          </div>

          {/* Interaction & Commentary Deck */}
          <div className="flex flex-col justify-between p-6 md:p-8 border-t border-neutral-850 md:border-t-0 md:border-l">
            {/* Top half section */}
            <div className="space-y-6">
              {/* Creator details row */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <img
                    src={pin.authorAvatar}
                    alt={pin.author}
                    referrerPolicy="no-referrer"
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div>
                    <span className="block font-sans text-sm font-bold text-white leading-tight">
                      {pin.author}
                    </span>
                    <span className="block font-sans text-[11px] text-neutral-500">
                      Aesthetic Studio Member
                    </span>
                  </div>
                </div>

                {/* Like Button with Pop Animation */}
                <motion.button
                  whileTap={{ scale: 1.25, rotate: [0, -10, 10, 0] }}
                  whileHover={{ scale: 1.05 }}
                  onClick={() => onLikeToggle(pin.id)}
                  className={`flex items-center gap-1.5 rounded-full px-4 py-1.5 border transition-all ${
                    pin.isLikedByUser
                      ? 'bg-red-950/40 border-red-900/40 text-red-500'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  <Heart className={`h-4 w-4 ${pin.isLikedByUser ? 'fill-red-500' : ''}`} />
                  <span className="font-sans text-xs font-semibold">{pin.likes}</span>
                </motion.button>
              </div>

              {/* Pin metadata texts */}
              <div className="space-y-2">
                <h1 className="font-sans text-2xl font-black text-white tracking-tight leading-tight">
                  {pin.title}
                </h1>
                <p className="font-sans text-sm text-neutral-400 leading-relaxed font-light">
                  {pin.description}
                </p>
              </div>

              {/* Downloader Diagnostic Summary in detail view */}
              <div className="rounded-xl bg-neutral-900 p-3 flex items-center justify-between border border-neutral-850">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-950/50 text-blue-500">
                    <Sparkles className="h-3.5 w-3.5" />
                  </span>
                  <div>
                    <span className="block font-sans text-xs font-bold text-neutral-350">
                      Ultra-Fast Cache
                    </span>
                    <span className="block font-sans text-[10px] text-neutral-500">
                      Available locally for repeat loading
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="block font-mono text-xs font-bold text-neutral-350">
                    {pin.downloadCount + (pin.downloadCount > 0 ? 0 : 5)}
                  </span>
                  <span className="block font-sans text-[9px] text-neutral-500 uppercase tracking-wider">
                    Downloads
                  </span>
                </div>
              </div>

              {/* Comments board toggle */}
              <div className="space-y-4">
                <button
                  onClick={() => setIsCommentsExpanded(!isCommentsExpanded)}
                  className="flex w-full items-center justify-between py-1.5 font-sans text-xs font-bold text-neutral-400 uppercase tracking-widest hover:text-white transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    <span>Comments ({filteredComments.length})</span>
                  </span>
                </button>

                {isCommentsExpanded && (
                  <div className="space-y-3.5 max-h-56 overflow-y-auto pr-1">
                    {filteredComments.map((comment) => (
                      <div key={comment.id} className="flex gap-2.5 items-start">
                        <img
                          src={comment.authorAvatar}
                          alt={comment.author}
                          referrerPolicy="no-referrer"
                          className="h-7 w-7 rounded-full object-cover mt-0.5"
                        />
                        <div className="rounded-xl bg-neutral-900 px-3 py-2 flex-grow max-w-[85%]">
                          <div className="flex justify-between items-baseline mb-0.5 gap-2">
                            <span className="font-sans text-xs font-bold text-neutral-250">
                              {comment.author}
                            </span>
                            <span className="font-sans text-[9px] text-neutral-550">
                              {comment.timestamp}
                            </span>
                          </div>
                          <p className="font-sans text-xs text-neutral-400 whitespace-normal leading-normal">
                            {comment.text}
                          </p>
                        </div>
                      </div>
                    ))}

                    {filteredComments.length === 0 && (
                      <div className="py-4 text-center font-sans text-xs text-neutral-500">
                        No comments yet. Be the first to express some feedback!
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Bottom half: Comment Submission Form */}
            <form onSubmit={handlePostComment} className="mt-6 flex gap-2 pt-4 border-t border-neutral-850">
              <input
                type="text"
                placeholder="Submit response..."
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="flex-grow rounded-full bg-neutral-900 border border-neutral-800 px-4 py-2.5 font-sans text-xs text-white placeholder-neutral-500 outline-none focus:border-neutral-650 focus:bg-neutral-900 transition-colors"
                maxLength={100}
              />
              <button
                type="submit"
                disabled={!newCommentText.trim()}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-velvet text-brand-cream transition-opacity hover:bg-brand-velvet-hover active:scale-95 disabled:opacity-45 shadow-[0_4px_10px_rgba(139,0,0,0.4)]"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </form>

          </div>
        </div>
      </div>

      {/* "More Like This" Staggered Grid Explore Section */}
      <div className="mt-12 border-t border-neutral-850 pt-10">
        <div className="flex items-center gap-2 mb-6">
          <div className="h-2 w-2 rounded-full bg-brand-velvet" />
          <h3 className="font-display text-lg font-bold text-brand-cream uppercase tracking-wider">
            More Like This
          </h3>
        </div>

        {overlappingPins.length > 0 ? (
          <div>
            <div className="grid grid-cols-2 gap-3 md:gap-4.5 max-w-full">
              {/* Column 1 */}
              <div className="flex flex-col gap-3 md:gap-4.5">
                {relatedCol1.map((relatedPin) => (
                  <div
                    key={relatedPin.id}
                    onClick={() => onSelectPin(relatedPin)}
                    className="group relative cursor-pointer overflow-hidden rounded-[16px] bg-[#1E1E1E] border border-neutral-850 transition-all hover:scale-[1.01] active:scale-99 hover:shadow-lg hover:shadow-brand-velvet/5 flex flex-col"
                  >
                    <CachedImage
                      src={relatedPin.url}
                      width={relatedPin.width}
                      height={relatedPin.height}
                      alt={relatedPin.title}
                      className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    
                    {/* Floating Info Overlays */}
                    <div className="p-3 bg-neutral-950/80 backdrop-blur-sm border-t border-neutral-900 rounded-b-[16px]">
                      <span className="block truncate font-display text-[10px] font-bold text-brand-cream">
                        {relatedPin.title}
                      </span>
                      <div className="flex justify-between items-center mt-1.5">
                        <span className="text-[9px] text-neutral-400 truncate max-w-[70%]">
                          @{relatedPin.author}
                        </span>
                        <div className="flex items-center gap-1 text-brand-velvet font-bold">
                          <Heart className="h-2.5 w-2.5 fill-brand-velvet text-brand-velvet" />
                          <span className="font-mono text-[9px]">{relatedPin.likes}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Column 2 */}
              <div className="flex flex-col gap-3 md:gap-4.5">
                {rCol2.map((relatedPin) => (
                  <div
                    key={relatedPin.id}
                    onClick={() => onSelectPin(relatedPin)}
                    className="group relative cursor-pointer overflow-hidden rounded-[16px] bg-[#1E1E1E] border border-neutral-850 transition-all hover:scale-[1.01] active:scale-99 hover:shadow-lg hover:shadow-brand-velvet/5 flex flex-col"
                  >
                    <CachedImage
                      src={relatedPin.url}
                      width={relatedPin.width}
                      height={relatedPin.height}
                      alt={relatedPin.title}
                      className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    
                    {/* Floating Info Overlays */}
                    <div className="p-3 bg-neutral-950/80 backdrop-blur-sm border-t border-neutral-900 rounded-b-[16px]">
                      <span className="block truncate font-display text-[10px] font-bold text-brand-cream">
                        {relatedPin.title}
                      </span>
                      <div className="flex justify-between items-center mt-1.5">
                        <span className="text-[9px] text-neutral-400 truncate max-w-[70%]">
                          @{relatedPin.author}
                        </span>
                        <div className="flex items-center gap-1 text-brand-velvet font-bold">
                          <Heart className="h-2.5 w-2.5 fill-brand-velvet text-brand-velvet" />
                          <span className="font-mono text-[9px]">{relatedPin.likes}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Infinite Scroll Monitoring node */}
            {visibleCount < overlappingPins.length && (
              <div
                ref={loaderRef}
                className="mt-8 py-6 flex flex-col items-center justify-center gap-2 select-none"
              >
                <div className="h-6 w-6 animate-spin rounded-full border-2 border-brand-velvet border-t-transparent" />
                <span className="font-sans text-[10px] text-neutral-500 uppercase tracking-widest animate-pulse">
                  Aligning similar vibes...
                </span>
              </div>
            )}

            {visibleCount >= overlappingPins.length && (
              <div className="mt-8 py-6 text-center border-t border-neutral-900">
                <span className="font-sans text-[10px] text-neutral-500 uppercase tracking-wider">
                  You have synced with all visuals of this aesthetic.
                </span>
              </div>
            )}
          </div>
        ) : (
          <div className="py-12 text-center rounded-2xl border border-dashed border-neutral-850 p-6 bg-neutral-900/10">
            <Sparkles className="h-5 w-5 mx-auto mb-2 text-brand-velvet animate-pulse" />
            <span className="block font-sans text-xs text-neutral-400">
              Generating visuals of similar styling tags...
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
