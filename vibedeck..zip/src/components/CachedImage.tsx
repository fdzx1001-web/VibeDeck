/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { getCachedImageUrl } from '../utils/imageCache';

interface CachedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  width: number;
  height: number;
  alt: string;
}

/**
 * Advanced Asynchronous Image Loader mimicking Android's Jetpack Compose AsyncImage.
 * Implements:
 * 1. Double tier memory + persistent disk caches.
 * 2. Visual layout preservation (exact aspect ratios) to stop cumulative layout shift (CLS).
 * 3. Minimalist shimmer state during background load.
 * 4. Micro-fade animations for entering images.
 */
export const CachedImage: React.FC<CachedImageProps> = ({ src, width, height, alt, ...rest }) => {
  const [resolvedSrc, setResolvedSrc] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Smooth aspect ratio
  const aspectRatio = width / height;

  useEffect(() => {
    // Create abort controller for request-canceling on rapid unmount / scroll recycle
    // This replicates Android view holder recycling cancellation!
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setHasError(false);
    setIsLoading(true);

    async function loadImage() {
      try {
        const cachedUrl = await getCachedImageUrl(src, controller.signal);
        setResolvedSrc(cachedUrl);
        setIsLoading(false);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          console.error(`[CachedImage] Error loading image: ${src}`, err);
          setHasError(true);
          setIsLoading(false);
          // Fallback to original URL
          setResolvedSrc(src);
        }
      }
    }

    loadImage();

    return () => {
      // Cancel active load on unmod/recycle to preserve cellular data and performance
      controller.abort();
    };
  }, [src]);

  return (
    <div
      className="relative w-full overflow-hidden bg-neutral-900"
      style={{
        aspectRatio: `${aspectRatio}`,
        borderRadius: '12px' // 12dp rounded corner
      }}
    >
      {/* Jetpack-style Shimmer Placeholder */}
      {(isLoading || !resolvedSrc) && (
        <div className="absolute inset-0 flex items-center justify-center bg-neutral-900">
          <div className="h-full w-full animate-pulse bg-gradient-to-r from-neutral-900 via-neutral-850 to-neutral-900" />
        </div>
      )}

      {/* Actual Rendered Image */}
      {resolvedSrc && (
        <img
          src={resolvedSrc}
          alt={alt}
          referrerPolicy="no-referrer"
          className={`h-full w-full object-cover transition-all duration-300 ease-out ${
            isLoading ? 'scale-105 opacity-0 blur-sm' : 'scale-100 opacity-100 blur-0'
          }`}
          onLoad={() => setIsLoading(false)}
          onError={() => {
            setHasError(true);
            setIsLoading(false);
          }}
          {...rest}
        />
      )}

      {/* Error State */}
      {hasError && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-neutral-850 p-2 text-center text-xs text-neutral-500">
          <span className="font-mono text-[9px] text-red-500 uppercase tracking-widest">Load Error</span>
        </div>
      )}
    </div>
  );
};
