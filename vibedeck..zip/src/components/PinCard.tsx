/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ImagePin } from '../types';
import { CachedImage } from './CachedImage';
import { Heart, Download, Bookmark } from 'lucide-react';

interface PinCardProps {
  pin: ImagePin;
  onClick: () => void;
  onSaveBoardClick: (e: React.MouseEvent) => void;
  onDownloadClick: (e: React.MouseEvent) => void;
}

/**
 * Animated individual Pinterest-style Card.
 * Adheres to "Clean Dark Theme" containing 12dp (12px on scale) rounded corners,
 * floating borderless image, and immersive tactile hover/tap feedback.
 */
export const PinCard: React.FC<PinCardProps> = ({
  pin,
  onClick,
  onSaveBoardClick,
  onDownloadClick
}) => {
  return (
    <motion.div
      onClick={onClick}
      className="group relative mb-5 break-inside-avoid cursor-pointer px-1 py-1 select-none"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: "spring", stiffness: 400, damping: 25 }}
    >
      <div className="relative overflow-hidden rounded-[12px] bg-neutral-900 transition-shadow duration-300 hover:shadow-[0_8px_30px_rgba(139,0,0,0.15)] md:hover:shadow-[0_8px_30px_rgba(0,0,0,0.65)]">
        {/* Asynchronous Cache Protected Image Component inside a Shared Element Container */}
        <motion.div
          layoutId={`pin-image-container-${pin.id}`}
          transition={{ type: "spring", stiffness: 350, damping: 30 }}
          className="w-full h-full"
        >
          <CachedImage
            src={pin.url}
            width={pin.width}
            height={pin.height}
            alt={pin.title}
          />
        </motion.div>

        {/* Floating High-Interactive Overlay visible on Hover (Desktop) / Touch (Mobile) */}
        <div className="absolute inset-0 flex flex-col justify-between bg-black/40 p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          <div className="flex justify-end gap-2">
            {/* Save to Board Button */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              whileHover={{ scale: 1.05 }}
              onClick={(e) => {
                e.stopPropagation();
                onSaveBoardClick(e);
              }}
              className="flex h-10 items-center justify-center gap-1.5 rounded-full bg-brand-velvet px-4 text-xs font-bold text-brand-cream transition-all hover:bg-brand-velvet-hover shadow-[0_4px_10px_rgba(139,0,0,0.5)]"
              title="Save to Deck"
            >
              <Bookmark className="h-3.5 w-3.5" />
              <span>Save to Deck</span>
            </motion.button>
          </div>

          <div className="flex items-center justify-between">
            {/* Quick Actions (e.g. download) */}
            <span className="truncate pr-2 font-sans text-xs font-semibold text-white drop-shadow-md">
              {pin.title}
            </span>

            <motion.button
              whileTap={{ scale: 0.85 }}
              whileHover={{ scale: 1.1 }}
              onClick={(e) => {
                e.stopPropagation();
                onDownloadClick(e);
              }}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-neutral-800/90 text-neutral-200 hover:text-white"
              title="Save to Device Gallery"
            >
              <Download className="h-4 w-4" />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Author Details Card Accessories (Clean minimal Pinterest style) */}
      <div className="mt-2 flex items-center justify-between px-1">
        <div className="flex items-center gap-1.5 max-w-[70%]">
          <img
            src={pin.authorAvatar}
            alt={pin.author}
            referrerPolicy="no-referrer"
            className="h-5 w-5 rounded-full object-cover"
          />
          <span className="truncate font-sans text-[11px] font-medium text-neutral-400 group-hover:text-neutral-200 transition-colors duration-200">
            {pin.author}
          </span>
        </div>
        <motion.div 
          className="flex items-center gap-1.5 text-neutral-450 hover:text-red-500 transition-colors duration-200"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 1.3, rotate: [0, -10, 10, 0] }}
        >
          <Heart className={`h-3.5 w-3.5 transition-colors duration-200 ${pin.isLikedByUser ? 'fill-red-600 text-red-600' : ''}`} />
          <span className="font-sans text-xs font-medium">{pin.likes}</span>
        </motion.div>
      </div>
    </motion.div>
  );
};
